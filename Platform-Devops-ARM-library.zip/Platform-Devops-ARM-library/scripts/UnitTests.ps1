# Clone arm-ttk repository
git clone https://github.com/Azure/arm-ttk.git

# Import the arm-ttk module from the clone repo directory
Import-Module ./arm-ttk/arm-ttk/arm-ttk.psd1

$TestResults = Test-AzTemplate -TemplatePath ./templates -SkipByFile @{
    '*.json' = '*apiVersions*'
    '*' = '*schema*','*vm size*'
    'aks.json' = '*blank*'
   }

# We only want to return failures
$TestFailures =  $TestResults | Where-Object { -not $_.Passed }

# If files are returning invalid configurations
# Using exit code "1" to let Github actions node the test failed
if ($TestFailures) {
    Write-Host "One or more templates did not pass the selected tests:"
    $TestFailures.file.name | select-object -unique
    Write-Host "Results:"
    Write-Output $TestFailures
    $TestResults.Summary
    exit 1
}

# Else, all passes and exit using exit code 0 indicating a success
else {
    Write-Host "All files passed!"
    Write-Output $TestResults
    exit 0
}

