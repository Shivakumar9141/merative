source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/log.sh"
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/check.sh"

function create_rg {
    local -r location="$1"
    local -r rg="$2"

    if ! check_rg_exists "$rg"; then
        log_warn "$rg does not exist in $location. Creating $rg."
        az group create -l "$location" -n "$rg" >/dev/null 2>&1
    else
        log_info "$rg already exists in $location."
    fi
}

function create_arm_vault {
    local -r location="$1"
    local -r vault_name="$2"
    local -r rg="$3"

    if ! check_vault_exists "$rg" "$vault_name"; then
        log_warn "$vault_name does not exist under $rg.Creating $vault_name."
        az keyvault create -l $location -n $vault_name -g $rg \
        --enabled-for-template-deployment true >/dev/null 2>&1
    else
        log_info "$vault_name already exists under $rg."
    fi
}

function create_armvault_access_policy {
    local -r vault_name="$1"
    local -r current_user_id=$(check_singed_in_user)

    az keyvault set-policy \
    --name "$vault_name" \
    --object-id "$current_user_id" \
    --secret-permissions all \
    --key-permissions list \
    --certificate-permissions list >/dev/null 2>&1
}

function recover_deleted_vaults {
    local -r location="$1"
    local -r rg="$2"
    shift
    local -ar deleted_vaults=($(az keyvault list-deleted --resource-type vault --query "[].name" -o tsv | tr -d '\r'))
    if check_deleted_vaults; then
        for vault in "${deleted_vaults[@]}"; do
            log_warn "Found $vault in deleted state.Recovering it to $rg."
            az keyvault recover -l $location -n $vault -g $rg >/dev/null 2>&1
        done
    else
        log_info "There are no keyvaults in the deleted state."
        return 1
    fi
}

function create_secret_generator {
    local -r secret_length="$1"
    local result=$(openssl rand -base64 "$secret_length")
    echo $result
}

function create_vault_secrets {
    local -r vault_name="$1"
    shift
    local -ar secret_list=("$@")

    for secret in "${secret_list[@]}"; do
        if ! check_vault_secret_exists "$vault_name" "$secret"; then
            log "$secret doesn't exist in $vault_name.Creating secret $secret."
            password="$(create_secret_generator 14)"
            az keyvault secret set --name $secret --vault-name $vault_name --value $password >/dev/null 2>&1
        else
            log_info "$secret already exists in $vault_name."
        fi
    done
}

function delete_unknown_role_assignments {
    local -r rg="$1"
    local -r orphan_roles_ids=$(az role assignment list -g "$rg" --query "[?principalName == '']".id -o tsv --only-show-errors | tr -d '\r')

    if check_orphan_role_assignments "$rg"; then
        log_info "There are no unknown role assignments in $rg."
    else
        log_warn "Found unknown role assignments.Deleting them"
        az role assignment delete --ids $orphan_roles_ids >/dev/null 2>&1
    fi
}

function create_template_spec {
    local -r rg="$1"
    local -r ts_name="$2"
    local -r location="$3"
    local -r ts_version="$4"
    local -r template_file_location="$5"

    if ! check_template_spec_exists "$ts_name" "$ts_version" "$rg"; then
        log_warn "$ts_name with $ts_version doesn't exist.Creating $ts_name with $ts_version"

        az ts create -g "$rg" -n "$ts_name" \
        --location "$location" \
        --display-name "${ts_name}-${ts_version}" \
        --version "$ts_version" \
        --template-file "$template_file_location" \
        --yes >/dev/null 2>&1
    else
        log_info "$ts_name with $ts_version already exists.Updating existing version $ts_version."
        update_template_spec "$ts_id" "$template_file_location"
    fi
}

function run_plan {
    local -r rg="$1"
    local -r params_file_path="$2"
    local ts_id="$ts_id"

    az deployment group create --resource-group "$rg" --what-if --template-spec "$ts_id" \
    --parameters "$params_file_path"
}

function deploy_template_spec {
    local -r rg="$1"
    local -r params_file_path="$2"
    local -r ts_name="$3"
    local -r ts_version="$4"
    local ts_id="$ts_id"

    az deployment group create --resource-group "$rg" --template-spec "$ts_id" \
    --parameters "$params_file_path" --name "${ts_name}-${ts_version}" --verbose
}

function update_template_spec {
    local ts_id="$ts_id"
    local -r template_file_location="$2"

    az ts update --template-spec "$ts_id" -f "$template_file_location" -y >/dev/null 2>&1
}