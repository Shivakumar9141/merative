#!/usr/bin/env bash

set -x

#################################################
# Globals and Defaults
#################################################

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly ARM_TEMPLATES_DIR="$SCRIPT_DIR/../templates"

#source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/bootstrap.sh"
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/create.sh"
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/check.sh"
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/log.sh"

#################################################
#
# Inputs CLI Function
#
#################################################


function print_usage {
    echo -e
    echo -e "Syntax: $0 [-s|e|l|t|v|p]"
    echo -e "options:"
    echo -e "s    Solution name."
    echo -e "e    environment."
    echo -e "l    Location."
    echo -e "t    Template Spec name."
    echo -e "v    Template Spec version."
    echo -e "p    Run plan."
    echo -e
}

function cli_input {
    plan='false'

    while [[ $# -gt 0 ]]; do
        local key="$1"

        case "$key" in
            -s)
                check_not_empty "$key" "$2"
                solution="$2"
                shift
            ;;
            -e)
                check_not_empty "$key" "$2"
                environment="$2"
                shift
            ;;
            -l)
                check_not_empty "$key" "$2"
                location="$2"
                shift
            ;;
            -t)
                check_not_empty "$key" "$2"
                tsname="$2"
                shift
            ;;
            -v)
                check_not_empty "$key" "$2"
                version="$2"
                shift
            ;;
            -p)
                plan='true'
            ;;
            -h)
                print_usage
                exit
            ;;
            *)
                log_error "Unrecognized argument: $key"
                print_usage
                exit 1
            ;;
        esac

        shift
    done
}

cli_input "$@"

#################################################
# Global Variables for All Functions
#################################################

PREFIX="${solution}-${environment}-${location}"
OPSRG="${PREFIX}-ops"
COMPUTERG="${PREFIX}-compute"
CLOUDSVCRG="${PREFIX}-cloudsvc"
ARMVAULTNAME="${PREFIX}-armikv"
OPSVNETNAME="${PREFIX}-vnet"
OPSAKSSUBNET="${PREFIX}-aks"
OPSVMSSUBNET="${PREFIX}-vm"
OPSBASTIONSUBNET="AzureBastionSubnet"

#################################################
# Validate Network Function
#################################################

function validate_network {
    # validating resource groups
    local -ra rgs=("$OPSRG" "$COMPUTERG" "$CLOUDSVCRG")
    local -r vnet_name="$OPSVNETNAME"
    local -ra subnets=("$OPSAKSSUBNET" "$OPSVMSSUBNET" "$OPSBASTIONSUBNET")

    for rg in "${rgs[@]}"; do
        if check_rg_exists "$rg"; then
            log_info "$rg already exists."
        else
            log_error "$rg doesn't exist.You cannot continue without having base network layed down."
            exit 1
        fi
    done

    # validating vnet
    if check_vnet_exists "$OPSRG" "$vnet_name"; then
        log_info "$vnet_name already exists"
    else
        log_error "$vnet_name doesn't exist.You cannot continue without having base network layed down."
        exit 1
    fi

    # validating subnets
    for subnet in "${subnets[@]}"; do
        if check_subnet_exists "$OPSRG" "$vnet_name" "$subnet"; then
            log_info "$subnet already exists."
        else
            log_error "$subnet doesn't exist.You cannot continue without having base network layed down."
            exit 1
        fi
    done
}

#################################################
# Validate Resources Function
#################################################

function validate_resources {
    local -r rg="$CLOUDSVCRG"
    local -r vault_name="$ARMVAULTNAME"
    local -ra secret_list=("postgresql-password" "hdcluster-password" "hdssh-password" "vm-password" "aml-admin-password")

    # create new keyvault if there are no recovered vaults
    if ! recover_deleted_vaults "$location" "$rg"; then
        create_arm_vault "$location" "$vault_name" "$rg"

        # check signed-in user was already added to the keyvault access policy, if not add it
        if ! check_signed_in_user_added_to_vault_policy "$vault_name"; then
            log_warn "Current user is not added to the $vault_name policy, adding it."
            create_armvault_access_policy "$vault_name"
        else
            log_info "Current user is already added to $vault_name access policies."
        fi
    fi

    # create secrets in vault if vault already exists
    create_vault_secrets "$vault_name" "${secret_list[@]}"

    # validating role assignments
    delete_unknown_role_assignments "$COMPUTERG"
}

#################################################
# Update Parameters Function
#################################################

function update_parameters {
    local current_parameters_file="$ARM_TEMPLATES_DIR/azuredeploy.params.json"
    local updated_parameters_file="$ARM_TEMPLATES_DIR/azuredeploy.parameters.json"

    jq --arg solution "$solution" \
    --arg environment "$environment" \
    --arg location "$location" \
    --arg opsrg "$OPSRG" \
    --arg opsvnet "$OPSVNETNAME" \
    --arg opsakssubnet "$OPSAKSSUBNET" \
    --arg opsvmssubnet "$OPSVMSSUBNET" \
    --arg armvaultname "$ARMVAULTNAME" \
    --arg armvaultrg "$CLOUDSVCRG" \
    '.parameters."solutionName".value |= $solution
    | .parameters."environmentName".value |= $environment
    | .parameters."location".value |= $location
    | .parameters."OpsVnetResourceGroupName".value |= $opsrg
    | .parameters."OpsVnetName".value |= $opsvnet
    | .parameters."aksSubnetName".value |= $opsakssubnet
    | .parameters."vmSubentName".value |= $opsvmssubnet
    | .parameters."vaultResourceGroupName".value |= $armvaultrg
    | .parameters."preDeployVaultName".value |= $armvaultname
    | .parameters."amlvnetResourceGroupName".value |= $opsrg
    | .parameters."amlvnetName".value |= $opsvnet
    | .parameters."amlsubnetName".value |= $opsvmssubnet' $current_parameters_file > $updated_parameters_file

    if [[ "$?" -eq 0 ]]; then
        return 0
    else
        log_error "Failed to update $updated_parameters_file."
        exit 1
    fi
}

#################################################
# Template Spec Function
#################################################

function validate_template_spec {
    local -r rg="$OPSRG"
    local -r ts_file_location="$ARM_TEMPLATES_DIR/azuredeploy.json"
    local -r params_file_path="$ARM_TEMPLATES_DIR/azuredeploy.parameters.json"

    create_template_spec "$rg" "$tsname" "$location" "$version" "$ts_file_location"

    # check if pre-flight validation for template spec is successful or failed
    if template_spec_preflight_validation "$rg" "$params_file_path" "$tsname" "$version"; then
        log_info "Template Spec validation was successful."
    else
        log_error "Template Spec validation has failed."
        exit 1
    fi
}

#################################################
# Template Spec Deployment Function
#################################################

function plan_or_deploy {
    local -r rg="$OPSRG"
    local -r params_file_path="$ARM_TEMPLATES_DIR/azuredeploy.parameters.json"

    if [[ "$plan" = 'true' ]]; then
        log_info "You have selected to run plan only.Running pre-deployment plan."
        run_plan "$rg" "$params_file_path"
    else
        log_warn "You have selected to directly deploy."
        read -p "Do you want to proceed? (yes/no) " yn

        case $yn in
            yes ) deploy_template_spec "$rg" "$params_file_path" "$tsname" "$version";;
            no ) echo deployment aborted by the user ...;
            exit;;
            * ) echo invalid response;
            exit 1;;
        esac

        # check deployment status
        if deploy_template_spec "$rg" "$params_file_path" "$tsname" "$version"; then
            log_info "Deployment has been successful."
            exit
        else
            log_error "Deployment has failed."
            exit 1
        fi
    fi
}

#################################################
# Calling the Functions Here
#################################################

log_info "Validating Base Network Required for Deployment ..."
validate_network

log_info "Validating Dependent Resources are Present ..."
validate_resources

log_info "Updating parameters file ..."
update_parameters

log_info "Validating Template Spec ..."
validate_template_spec

log_info "Plan or Deploy ..."
plan_or_deploy