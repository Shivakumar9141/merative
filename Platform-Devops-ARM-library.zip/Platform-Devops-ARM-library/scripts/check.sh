#!/usr/bin/env bash

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/log.sh"


function check_not_empty {
    local -r arg_name="$1"
    local -r arg_value="$2"

    if [[ -z "$arg_value" ]]; then
        log_error "The value for '$arg_name' cannot be empty."
        exit 1
    fi
}

function check_array_contains_string {
    local -r str="$1"
    shift
    local -ra lst=("$@")

    local item
    for item in "${lst[@]}"; do
        if [[ "$item" == "$str" ]]; then
            return 0
        fi
    done

    return 1
}

function check_rg_exists {
    local -r rg="$1"
    az group show -n "$rg" --query id >/dev/null 2>&1
}

function check_vnet_exists {
    local -r rg="$1"
    local -r vnet="$2"
    az network vnet show -g "$rg" -n "$vnet" --query id >/dev/null 2>&1
}

function check_subnet_exists {
    local -r rg="$1"
    local -r vnet="$2"
    local -r subnet="$3"
    az network vnet subnet show -g "$rg" -n "$subnet" --vnet-name "$vnet" --query id >/dev/null 2>&1
}

function check_orphan_role_assignments {
    local -r rg="$1"
    local -r orphan_ids=$(az role assignment list -g "$rg" --query "[?principalName == '']".id -o tsv --only-show-errors)

    [[ -z "$orphan_ids" ]]
}

function check_vault_exists {
    local -r rg="$1"
    local -r vault_name="$2"
    az keyvault show -g "$rg" -n "$vault_name" --query id >/dev/null 2>&1
}

function check_vault_secret_exists {
    local -r vault_name="$1"
    local -r secret="$2"
    az keyvault secret show --name  "$secret" --vault-name "$vault_name" --query id >/dev/null 2>&1
}

function check_deleted_vaults {
    local -r deleted_vault_ids=$(az keyvault list-deleted --resource-type vault --query "[].id" -o tsv)
    ! [[ -z "$deleted_vault_ids" ]]
}

function check_singed_in_user {
    local -r current_user_id=$(az ad signed-in-user show --query id -o tsv --only-show-errors | tr -d '\r')
    echo $current_user_id
}

function check_signed_in_user_added_to_vault_policy {
    local -r vault_name="$1"
    local -r current_user_id=$(check_singed_in_user)
    shift
    local -ar vault_access_policies_list=($(az keyvault show --name "$vault_name" --query "properties.accessPolicies[*].objectId" -o tsv | tr -d '\r'))

    check_array_contains_string "$current_user_id" "${vault_access_policies_list[@]}"
}

function check_template_spec_exists {
    local -r ts_name="$1"
    local -r ts_version="$2"
    local -r rg="$3"
    ts_id=$(az ts show -g "$rg" --name "$ts_name" --version "$ts_version" --query id -o tsv)

    ! [[ -z "$ts_id" ]]
}

function template_spec_preflight_validation {
    local -r rg="$1"
    local -r params_file_path="$2"
    local -r ts_name="$3"
    local -r ts_version="$4"

    ts_id=$(az ts show -g "$rg" --name "$ts_name" --version "$ts_version" --query id -o tsv)

    az deployment group validate --resource-group "$rg" --template-spec "$ts_id" --parameters "$params_file_path"
}