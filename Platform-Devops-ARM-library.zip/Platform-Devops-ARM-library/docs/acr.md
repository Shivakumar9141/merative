### Description

Azure Container Registry is a managed registry service based on the open-source Docker Registry 2.0. Used to create and maintain Azure container registries to store and manage your container images and related artifacts.
Usage:-  Azure Container Registry allows you to build, store, and manage container images and artifacts in a private registry for all types of container deployments. We can also use Azure container registries with existing container development and deployment pipelines. Use Azure Container Registry Tasks to build container images in Azure on-demand, or automate builds triggered by source code updates, updates to a container's base image, or timers.

### Prerequisites:-  
- Need to have valid subscription - Need to have contributor or above role for the subscription.
### Steps:-

1.	Copy the acr.json from templates/acr.json in from Platform-Devops-ARM-library repo.
2.	Navigate to Azure portal and select option "Custom Deployment"
3.	Select option "Build our own template"
4.	Paste the template of Step 1 in the editor and Click on Save
5.	User will be presented to edit the parameters below, please select or enter the values of the parameters as specified
6.	Once all parameters specified, click on review and create option, this will validate the template
7.   If the validation is passed, click to create acr template.

#### Parameters

##### Acr Name
- type : string
- description : Name of Azure Container Registry

##### Location
- type : string
- description : Specifies the Azure location where the acr should be created.

##### Acr sku
- type : string
- description : Azure Container registry tier.

##### enable system identity
- type : bool
- description :  Enable system identity for ACR.

##### User assigned identites
- type : object
- description :  List of user identity resource IDs to associate with ACR.


##### enable admin user
- type : bool
- description : Enable Admin user

##### Public Network access
- type : string
- description : Enable public network access.

##### Zone Redundancy
- type : string
- description : Enable zone redundancy

##### ipRules
- type : object
- description : Network rule set for a container registry

##### Network rule bypass options
- type : string
- description- Allow trusted azure services to access a network restricted registry.

##### Policies
- type : object
- description : Azure Container registry policies.

####  Azure Resource Type
	Microsoft.ContainerRegistry/registries

#### Properties

- adminUserEnabled
- networkRuleBypassOptions
- policies
- zoneRedundancy
- PublicNetworkAccess
#### SCIA Specific Changes:-
•	Scia team added below two new parameters to the template:
1.	g_hitrust_hippa : It is a Boolean parameter which when true, will enable additional settings and resources needed for compliance with HITRUST/HIPPA initiative.
2.	 s_actlogs_workspace_id : It is of type string and need to provide the azure monitor log analytics workspace resource id.


