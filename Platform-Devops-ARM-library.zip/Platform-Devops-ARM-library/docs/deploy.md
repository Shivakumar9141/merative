## Options For Deploying ARM Templates

### Deploy Using Azure Portal

### Deploy Using Visual Studio IDE

### Deploy Using Azure CLI

### Deployment Script

Convert windows formated files to unix
```
find . -type f -print0 | xargs -0 dos2unix
```
Create package and deploy using docker
```
docker build -t <image-name>
docker run -it --rm --name <container-name> -v ${PWD}:/usr/src/arm-code <image-name> bash
az login
scripts/deployment.sh
```
Create package and deploy on non-docker platforms
```
az login
scripts/deployment.sh
```
Run unit tests only
```
pwsh scripts/UnitTests.ps1
```
