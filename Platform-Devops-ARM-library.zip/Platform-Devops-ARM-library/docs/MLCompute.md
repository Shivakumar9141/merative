## Resource: 
Microsoft.MachineLearningServices/workspaces/computes

## Usage:
Azure Machine Learning Compute can be reused across runs. The compute can be shared with other users in the workspace and is retained between runs, automatically scaling nodes up or down based on the number of runs submitted, and the max_nodes set on your cluster. The min_nodes setting controls the minimum nodes available.

## Objective:
Compute clusters can be created in a different region than your workspace. This functionality is in preview, and is only available for compute clusters, not compute instances. This preview isn't available if you're using a private endpoint-enabled workspace.
When using a compute cluster in a different region than your workspace or datastores, you may see increased network latency and data transfer costs. The latency and costs can occur when creating the cluster, and when running jobs on it.

## Prerequisites: 
- Workspace name: The name of the Azure Machine Learning workspace to which compute instance will be deployed
- vnet & subnet in "ops" Resource group

## Steps:
- Copy the azuremlcompute.json from templates/ azuremlcompute.json in from Platform-Devops-ARM-library repo.
- Navigate to Azure portal and select option "Custom Deployment"
- Select option "Build our own template"
- Paste the template of Step 1 in the editor and Click on Save
- User will be presented to edit the parameters below, please select or enter the values of the parameters as specified
- Once all parameters specified, click on review and creation option, this will validate the template
- if the validation is passed, click to create mlcompute template


### Parameters:
- Subscription : select the subscription name from the drop down in which ml to be deployed
- Resource group : Select an existing resource group where a resource need to be deployed or create a new resource group by clicking "Create New" link
- Region : Select region where the resource need to be deployed
- workspaceName – Specifies the name of the Azure Machine Learning workspace to which compute instance will be deployed,  first need to execute a workspace template, then give a same name of workspace (Platform-Devops-ARM-library/azuremlworkspace.json at mainline · wh-devOps/Platform-Devops-ARM-library (github.com) )
- clusterName – Specifies the name of cluster given in Alphanumerics and hyphens.
- minNodeCount – mention a minimum number of nodes to use (as per project requirement)
- maxNodeCount – mention a maximum number of nodes to use (as per project requirement)
- location – Specifies the Azure location where the ml should be created, user need not enter this as its fetched by default using resougseGroup.location. (https://learn.microsoft.com/en-us/azure/availability-zones/az-overview).
- adminUserName – mention a admin user name, the administrator user account which can be used
- adminUserPassword -  mention a admin password, used for the administrator account
- vmSize – Specifies the size of the vm as per project requirement (https://learn.microsoft.com/en-us/azure/virtual-machines/sizes)
- VnetResourceGroupName - Specifies the existing vnet resource group name, as per SCIA this will be available under "ops" Resource group. Hence select the resource group where vnet is already exist.
- vnetName – Specifies the existing vnet name, as per SCIA this will be available under "ops" Resource group. 
- subetName - Specifies the subnet name which are already available in above selected vnet


### Default Values: 
- workspaceName - Specifies the name of the Azure Machine Learning Workspace which will contain this compute
- clusterName - Specifies the name of the Azure Machine Learning Compute cluster
- minNodeCount - The minimum number of nodes to use on the cluster. If not specified, defaults to 0
- maxNodeCount - The maximum number of nodes to use on the cluster. If not specified, defaults to 4
- location - The location of the Azure Machine Learning Workspace
- adminUserName - The name of the administrator user account which can be used to SSH into nodes. It must only contain lower case alphabetic characters [a-z].
- adminUserPassword - The password of the administrator user account.
- vmSize - The size of agent VMs
- VnetResourceGroupName - Name of the resource group which holds the VNET to which you want to inject your compute in.
- vnetName - Name of the vnet which you want to inject your compute in.
- subetName - Name of the subnet inside the VNET which you want to inject your compute in.

### Description:  
Azure Machine Learning compute cluster is a managed-compute infrastructure that allows you to easily create a single or multi-node compute. The compute cluster is a resource that can be shared with other users in your workspace. The compute scales up automatically when a job is submitted, and can be put in an Azure Virtual Network. Compute cluster supports no public IP (preview) deployment as well in virtual network. The compute executes in a containerized environment and packages your model dependencies in a Docker container.
Compute clusters can run jobs securely in a virtual network environment, without requiring enterprises to open up SSH ports. The job executes in a containerized environment and packages your model dependencies in a Docker container.
Azure Resource Name: Azure Machine Learning Compute Cluster

### Properties: 
computeType
vmSize
scaleSettings:
- minNodeCount
- maxNodeCount
userAccountCredentials:
- adminUserName
- adminUserPassword
subnet


### Values of properties:
- computeType: AmlCompute
- vmSize: [parameters('vmSize')]
- scaleSettings: 
- minNodeCount: [parameters('minNodeCount')]
- maxNodeCount: [parameters('maxNodeCount')]
- userAccountCredentials:
- adminUserName: [parameters('adminUserName')]
- adminUserPassword: [parameters('adminUserPassword')]
- subnet: [parameters('subnet')]

SCIA specific changes: NA

