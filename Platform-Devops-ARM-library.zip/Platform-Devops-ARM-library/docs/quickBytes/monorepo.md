# Right repo strategy
Building a repository strategy is not only about technical consideration but also about how people communicate.

As Conway’s Law states, communication is essential for building great products.

Choice of multi repo and mono repo have aspects of managing the repo independently  with collaboration barriers vs people working on central hub of communication among developer, engineer, tester and other stake holders, encouraging conversations and crack the silos.

Success of monorepos observed in many open source projects  but there are lot of success stories from product players such as google, Airbnb, Microsoft , Uber.

- A monorepo is version controlled code repo that holds many projects. These projects could be related, they are often logically independent and run by different teams.
- Organizations that overcome technical challenges associated with adopting monorepos enjoy significant benefits.
- some orgs host all their code in single repository, shared with ever one.
-  Mono can be immense in size.
### e.g. google, is theorised to have largest code repository. This have 10 of hundred of commit per day and is over 80TB's large. Other org's know to host large monorepos are Miscrosoft, facebook and twitter.

### Some of the advantages of monorepos


- Visibility : Code sharing for better collaboration and cross-team contributions where a developer from various team can contribute
- Simpler dependency management : Package manager need is reduced as all modules in same repository.
- Consistency : Ease of implementing code quality standard and unified style
- Shared timeline : Breakdown is exposed in realtime forcing team to communicate and join forces to fix.
- Atomic commits : Ease of refactoring. Update several packages in single commit.
- Implicit CI : All code is already unified which ensure the continous integration
- Unified CI/CD : Across projects c=same CI/CD deployment
- Unified build process


Source : semaphoreci

##### Author : Usman Shaik
