# JSON Visualisation

## Do you know you have option to visualise your JSON data ?

## here is the editor for same jsoncrack.com

## Some of the features :

- ease of use : Don't even bother to update your schema to view your JSON into graphs; directly paste, import or fetch! JSON Crack helps you to visualise without any additional values and save your time.

- Search : Have a huge file of values, keys or arrays? Worry no more, type in the keyword you are looking for into search input and it will take you to each node with matching result highlighting the line to understand better!

- Download : Download the graph to your local machine and use it wherever you want, to your blogs, website or make it a poster and paste to the wall. Who wouldn't want to see a JSON Crack graph onto their wall, eh?

- Live : With Microsoft's Monaco Editor which is also used by VS Code, easily edit your JSON and directly view through the graphs. Also there's a JSON validator above of it to make sure there is no type error.

![Visual Mapping of JSON in jasoncrack](visuals/jsoncrack.jpg)



### Sources : jsoncrack

##### Author : Usman Shaik
