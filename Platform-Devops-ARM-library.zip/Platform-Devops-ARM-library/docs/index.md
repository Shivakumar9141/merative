## About DevOps Team

Our main objective to onboard teams on Azure cloud. We deliver Infrastructure as Code using Azure ARM templates.
- Infrastructure as code are JSON files that define the infrastructure and configuration for your deployment
- Uses declarative syntax.
- Resource Manager orchestrates the deployment of the resources
- integrate your ARM templates into continuous integration and continuous deployment (CI/CD) tools
### Benefits :
1. Consistent configurations
2. Improved scalability
3. Faster deployments
3. Better traceability



### How do we Do ?
1. Automate the cloud infrastructure requirements
2. Create CI/CD pipeline for the VM based deployments
3. Guide team on using toolchain on Azure cloud

### Services
1. ARM Templates - IaC
2. Azure architecture consultation
3. Pipeline configuration and Automation
4. Capacity Planning

### Achievements

#### Completed
- Automated Cloud Resource requirement for HI Claims POC.
- Deployed Jenkins instance on Azure VM and built CI-CD pipeline for HI Claims POC.

#### In Progress
- Onboarding (AHRW)  AdHoc Report Writer – Emerald City Team on Azure
- Onboarding Vista development Team on Azure cloud

#### Planning Stage
HI BI team Onboarding on Azure Cloud
