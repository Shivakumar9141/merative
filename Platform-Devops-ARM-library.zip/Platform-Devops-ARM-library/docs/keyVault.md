## Key Vault
Azure Key Vault is a cloud service that provides a secure store for secrets, such as keys, passwords, certificates, and other secrets.

### Description
Azure Key Vault is a cloud service for securely storing and accessing secrets. A secret is anything that you want to tightly control access to, such as API keys, passwords, certificates, or cryptographic keys.

### Usage
Centralizing storage of application secrets in Azure Key Vault allows you to control their distribution. Key Vault greatly reduces the chances that secrets may be accidentally leaked. When using Key Vault, application developers no longer need to store security information in their application. Not having to store security information in applications eliminates the need to make this information part of the code. For example, an application may need to connect to a database. Instead of storing the connection string in the app's code, you can store it securely in Key Vault.

### Pre-req

- Need to have valid subscription 
- Need to have contributor or above role for the subscription 

### Steps 
1. Copy the KeyVault.json from templates/keyvault.json in from Platform-Devops-ARM-library repo.
2. Navigate to Azure portal and select option "Custom Deployment"
3. Select option "Build our own template"
4. Paste the template of Step 1 in the editor and Click on Save
5. User will be presented to edit the parameters below, please select or enter the values of the parameters as specified 
6. Once all parameters specified, click on review and creation option, this will validate the template
7. if the validation is passed, click to create Keyvault template.

### Parameters :

- Subscription : select the subscription name from the drop down in which keyvault to be deployed
- Resource group : Select an existing resource group where a resource need to be deployed or create a new resource group by clicking "Create New" link
- Region : Select region where the resource need to be deployed, as per SCIA this need to be deployed under "Cloud svc" Resource group. Hence select the resource group name with "cloudsvc" postfix. If not create compute resource group.
- keyVaultName : Specifies the name of the key vault. This can be of type string and it should be unique within the subscription must be globally unique across Azure.
**Note** : As the keyVault are soft delete, so if the name matches with the deleted key vault,  user will not be able to use the name again.
- Location : Specifies the Azure location where the key vault should be created, user need not enter this as its fetched by default using resougseGroup.location.
- enabledForDeployment : Type for this field is Boolean, user need to specify true or false.
	- false :  Azure Virtual Machines are not permitted to retrieve certificates stored as secrets from the key vault.
	- true  :  Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault
- enabledForDiskEncryption : Type for this field is Boolean, user need to specify true or false.
	- false : Azure Disk Encryption is not permitted to retrieve secrets from the vault and unwrap keys.
	- true : Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys.
- enabledForTemplateDeployment : Type for this field is Boolean, user need to specify true or false.
	- false : Azure Resource Manager is not permitted to retrieve secrets from the key vault
	- true : Azure Resource Manager is permitted to retrieve secrets from the key vault
- enableRbacAuthorization : Type for this field is Boolean, user need to specify true or false. If null or not specified, the vault is created with the   default value of false. 
	- false :  The key vault will use the access policies specified in vault properties, and any policy stored on Azure Resource Manager will be ignored
	- true : Key vault will use Role Based Access Control (RBAC) for authorization of data actions, and the access policies specified in vault properties will be ignored
- enableSoftDelete : Type for this field is Boolean, user need to specify true or false. Property to specify whether the 'soft delete' functionality is enabled for this key vault. Default value is true. Once set to true, it cannot be reverted to false
	- false : soft delete is disabled and all key vaults are deleted hence cannot be retrieved.
	- true : Soft delete is enabled and will follow purge protection policy
- enablePurgeProtection : Type for this field is Boolean, user need to specify true or false. Purge protection is an optional feature of Azure Key Vault which is disabled by default. Can be enabled once soft delete is enabled for keyvault. Soft-deleted vaults and objects can still be recovered, ensuring that the retention policy will be followed. Please note that the purge protection retention policy uses the same interval as soft delete. Once the period is set, the retention policy interval cannot be changed.
	- false : keyvault values are not purged
	- true : a vault or an object in the deleted state cannot be purged until the retention period has passed.
- tenantId : Specifies the Azure Active Directory tenant ID that should be used for authenticating requests to the key vault. The value can be fetched using subscrpition.tenantid() function. User doesn't have to modify this if using azure portal to deploy the resource. This fetched from active directory for this user need to have valid subscription. User can verify the tenant ID from the Azure active directory 
- skuName : Specifies whether the key vault is a standard vault or a premium vault. Aure Key Vault is currently offered in two service tiers: Standard and Premium. Key Vault in Standard tier is limited to secrets and software-protected keys, while Key Vault in Premium tier additionally supports keys stored in Hardware Security Modules (HSMs) and are FIPS 140-2 Level 3 validated.
- keysPermissions : This is of type array. This specifies the permissions to keys in the vault. Valid values are: all, encrypt, decrypt, wrapKey, unwrapKey, sign, verify, get, list, create, update, import, delete, backup, restore, recover, and purge. Currently used are "get" and "list". 
	- get : This will fetch the key's from the key Vault
	- list :  This will list the list the keys of the key Vault.
- secretsPermissions : This will fetch and list the permissions to secrets in the vault. Valid values are: all,get, list, set, delete, backup, restore, recover, and purge. Currently used are "get" and "list". 
	- get : This will fetch the key's from the key Vault
	- list :  This will list the list the keys of the key Vault.
- certificatePermissions : This will fetch and list the permissions to certificates in the vault. Valid values are: all, get, list, set, delete, backup, restore, recover, and purge. Currently used are "get" and "list". 
	- get : This will fetch the key's from the key Vault
	- list :  This will list the list the keys of the key Vault.

- objectId : The object ID of a key vault user or service principal or security group in the Azure  Active Directory tenant for the vault. The objectID should be replaced with the "null" value in the policies for the object key.
	- Keyvault user : User need to navigate to Azure active directory, click on view profile and copy the objectID value.
	- Service  principal :  User need to navigate to Azure active directory -> App Registrations -> Select the service principal created and click. Copy the object ID
	- security group :  User need to navigate to Azure active directory and click on  Groups - > Search for the security Group and copy the object ID
 


### Parameters :

- keyVaultName
- type : string
- description : Specifies the name of the key vault. enter a name for the key vault, which must be globally unique across Azure.

- Location
- type: string
- description- Specifies the Azure location where the key vault should be created.

- enabledForDeployment
- type : bool
- description : Specifies whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault.

- enabledForDiskEncryption
- type : bool
- description : Specifies whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys.

- enabledForTemplateDeployment
- type : bool
- description : Specifies whether Azure Resource Manager is permitted to retrieve secrets from the key vault.



- enableRbacAuthorization
- type : bool
- description : Property that controls how data actions are authorized. When true, the key vault will use Role Based Access Control (RBAC) for authorization of data actions, and the access policies specified in vault properties will be ignored. When false, the key vault will use the access policies specified in vault properties, and any policy stored on Azure Resource Manager will be ignored. If null or not specified, the vault is created with the default value of false. Note that management actions are always authorized with RBAC.

- enableSoftDelete
- type : bool
- description : Property to specify whether the 'soft delete' functionality is enabled for this key vault. If it's not set to any value(true or false) when creating new key vault, it will be set to true by default. Once set to true, it cannot be reverted to false.

- tenantId
- type : string
- description : Specifies the Azure Active Directory tenant ID that should be used for authenticating requests to the key vault.


- keysPermissions
- type : array
- description : Specifies the permissions to keys in the vault. Valid values are: all, encrypt, decrypt, wrapKey, unwrapKey, sign, verify, get, list, create, update, import, delete, backup, restore, recover, and purge.

- secretsPermissions
- type : array
- description : Specifies the permissions to secrets in the vault. Valid values are: all,    get, list, set, delete, backup, restore, recover, and purge.


- certificatePermissions
- type : array
- description : Specifies the permissions to certificates in the vault. Valid values are: all,      get, list, set, delete, backup, restore, recover, and purge.


- skuName
- type : string
- description : Specifies whether the key vault is a standard vault or a premium vault.


- objectId
- type – securestring
- description : The object ID of a user, service principal or security group in the Azure  Active Directory tenant for the vault. The object ID must be unique for the list of access  policies.


### Azure Resource Type
  - "Microsoft.KeyVault/vaults" : Microsoft.KeyVault/vaults
	- Properties
	- enabledForDeployment
	- enabledForDiskEncryption
  - enabledForTemplateDeployment
  - enableRbacAuthorization
  - enableSoftDelete
  - enablePurgeProtection
  - tenantId
  - accessPolicies

### SCIA Specific Changes
- enableRbacAuthorization


#### [Azure Resources](azureresources.md)


