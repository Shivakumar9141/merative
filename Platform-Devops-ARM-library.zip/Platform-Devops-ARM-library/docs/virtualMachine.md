## Virtual Machine
Azure VM is a cloud service that gives you the flexibility of virtualization without having to buy and maintain the physical hardware that runs it.

## Description
Virtual machines allow you to run an operating system in an app window on your desktop that behaves like a full, separate computer. You can use them play around with different operating systems, run software your main operating system can't, and try out apps in a safe, sandboxed environment.

## Usage
Azure virtual machines can be used in various ways. Some examples are:
Development and test – Azure virtual machines offer a quick and easy way to create a computer with specific configurations required to code and test an application.
Applications in the cloud – Because demand for your application can fluctuate, it might make economic sense to run it on a virtual machine in Azure. You pay for extra virtual machines when you need them and shut them down when you don’t.
Extended datacenter – Virtual machines in an Azure virtual network can easily be connected to your organization’s network.
The number of virtual machines that your application uses can scale up and out to whatever is required to meet your needs.
### Pre-req
Need to have a valid Azure subscription - Need to have contributor or owner role for the subscription.
### Steps
1.	Copy the vm.json from templates/vm.json in from Platform-Devops-ARM-library repo.
2.	Navigate to Azure portal and select option "Custom Deployment"
3.	Select option "Build our own template"
4.	Paste the template of Step 1 in the editor and Click on Save
5.	User will be presented to edit the parameters below, please select or enter the values of the parameters as specified
6.	Once all parameters specified, click on review and creation option, this will validate the template
7.	If the validation is passed, click to create the VM template.

### Parameters :
- Subscription : Select the subscription name from the drop down in which VM to be deployed
- Resource group : Select an existing resource group where a resource need to be deployed or create a new resource group by clicking "Create New" link
- Region : Select region where the resource need to be deployed, as per SCIA this need to be deployed under "compute" Resource group. Hence select the resource group name with "compute" postfix. If not, create compute resource group.
- VMName : Specifies the name of the virtual machine. This can be of type string and it should be unique within the subscription must be globally unique across Azure. 
- Location : Specifies the Azure location where the Virtual machine should be created, user need not enter this as its fetched by default using resourceGroup().location.
- enableavailabilitySet : Type for this field is Boolean, user need to specify true or false.
    - false : Won’t be able to create availabilitySet by setting this to false
    - true : Setting this to true will create availabilitySet
- enableloadBalancer : Type for this field is Boolean, user need to specify true or false.
    - false : Set this to false if you don’t want to create loadBalancer 
    - true : Set this to true to create loadBalancer
- adminUsername : Specifies the username of the Admin for virtual machine. This can be of type string and it should be unique within the subscription must be globally unique across Azure.
- numberOfInstances : Type for this field is int. User need to specify the number of VMs to deploy.
- OS : Type for this field is string. User need to specify the OS platform for the VM which can be either Redhat or Windows.
- authenticationType : Type for this field is string. User need to specify the type of authentication to use on the Virtual Machine. SSH key is recommended. Although  password can also be used.
- adminPasswordOrKey : Type for this field is securestring. User need to specify the SSH Key or password for the Virtual Machine. SSH key is recommended.
- vmSize : Type for this field is string. User need to specify the size of the virtual machine.
- storageAccountType : Type for this field is string. User need to specify the Storage type for data disks from the available allowed values :-
    - "PremiumV2_LRS",
    - "Premium_LRS",
    - "Premium_ZRS",
    - "StandardSSD_LRS",
    - "StandardSSD_ZRS",
    - "Standard_LRS",
    - "UltraSSD_LRS"
- sizeOfDataDisksInGB : Type for this field is int. User need to specify the Size of the data disk in GB format.
- virtualNetworkName : Type for this field is string. User need to specify the name of the existing virtual network for the VM.
- osDiskName : Type for this field is string. User need to specify the name of the VM OS Disk.
- dataDiskName : Type for this field is string. User need to specify the name of the VM dataDisk.
- virtualNetworkResourceGroup : Type for this field is string. User need to specify the name of the virtual network resource group.
- subnetName : Type for this field is string. User need to specify the name of the subnet in the virtual network you want to use.
- availabilitySetName : Type for this field is string. User need to specify the name of the availability set.
- loadBalancerName : Type for this field is string. User need to specify the name of load Balancer.
- bootDiagnosticsStorageAccount : Type for this field is string. User need to specify the name of the Storage Account for boot diagnostics.
