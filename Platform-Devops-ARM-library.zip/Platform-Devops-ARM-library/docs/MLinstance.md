## Resource: 
Microsoft.MachineLearningServices/workspaces/computes

## Usage:  
- Secure your compute instance with No public IP (preview)
- The compute instance is also a secure training compute target similar to compute clusters, but it is single node.
- You can create a compute instance yourself, or an administrator can create a compute instance on your behalf.
- You can also use a setup script (preview) for an automated way to customize and configure the compute instance as per your needs.
- To save on costs, create a schedule (preview) to automatically start and stop the compute instance.

## Objective: 
Use a compute instance as your fully configured and managed development environment in the cloud. For development and testing, you can also use the instance as a training compute target or for an inference target. A compute instance can run multiple jobs in parallel and has a job queue. As a development environment, a compute instance can't be shared with other users in your workspace.

## Prerequisites:
- compute instances, ensure you have a workspace.
- Workspace name: The name of the Azure Machine Learning workspace to which compute instance will be deployed
- vnet & subnet in "ops" Resource group

## Steps:
- Copy the azuremlinstance.json from templates/ azuremlinstance.json in from Platform-Devops-ARM-library repo.
- Navigate to Azure portal and select option "Custom Deployment"
- Select option "Build our own template"
- Paste the template of Step 1 in the editor and Click on Save
- User will be presented to edit the parameters below, please select or enter the values of the parameters as specified
- Once all parameters specified, click on review and creation option, this will validate the template
- if the validation is passed, click to create mlinstance template




### Parameters:
- Subscription : select the subscription name from the drop down in which ml to be deployed
- Resource group : Select an existing resource group where a resource need to be deployed or create a new resource group by clicking "Create New" link
- Region : Select region where the resource need to be deployed
- workspaceName -Specifies the name of the Azure Machine Learning workspace to which compute instance will be deployed,  first need to execute a workspace template, then give a same name of workspace (Platform-Devops-ARM-library/azuremlworkspace.json at mainline · wh-devOps/Platform-Devops-ARM-library (github.com) )
- computeName – Specifies the name of cluster given in Alphanumerics and hyphens.
- location – Specifies the Azure location where the ml should be created, user need not enter this as its fetched by default using resougseGroup.location. (https://learn.microsoft.com/en-us/azure/availability-zones/az-overview).
- vmSize – Specifies the size of vm as per project requirement (https://learn.microsoft.com/en-us/azure/virtual-machines/sizes)
- VnetResourceGroupName - Specifies the existing vnet resource group name, as per SCIA this will be available under "ops" Resource group. Hence select the resource group where vnet is already exist.
- vnetName – Specifies the existing vnet name, as per SCIA this will be available under "ops" Resource group. 
- subetName - Specifies the subnet name which are already available in above selected vnet
- inlineCommand – have to mention a inline command
- creationScript.cmdArguments - Specifies the cmd arguments of the creation script in the storage volume of the Compute Instance
- schedules - Specifies the schedule policies for the compute instance


### Default Values: 
- workspaceName - Specifies the name of the Azure Machine Learning workspace to which compute instance will be deployed
- computeName - Specifies the name of the Azure Machine Learning compute instance to be deployed
- location - Location of the Azure Machine Learning workspace
- vmSize - The VM size for compute instance
- VnetResourceGroupName - Name of the resource group which holds the VNET to which you want to inject your compute instance in
- vnetName - Name of the vnet which you want to inject your compute instance in
- subetName - Name of the subnet inside the VNET which you want to inject your compute instance in
- tenantId - AAD tenant id of the user to which compute instance is assigned to
- objectId - AAD object id of the user to which compute instance is assigned to
- inlineCommand - ls
- schedules - Specifies the cmd arguments of the creation script in the storage volume of the Compute Instance, use below mentioned schedules 
- "schedules": {
            "value": {
                "computeStartStop": [
                    {
                        "triggerType": "Cron",
                        "cron": {
                            "timeZone": "UTC",
                            "expression": "0 18 * * *"
                        },
                        "action": "Stop",
                        "status": "Enabled"
                    },
                    {
                        "triggerType": "Cron",
                        "cron": {
                            "timeZone": "UTC",
                            "expression": "0 8 * * *"
                        },
                        "action": "Start",
                        "status": "Enabled"
                    },
                    {
                        "triggerType": "Recurrence",
                        "recurrence": {
                            "frequency": "Day",
                            "interval":1,
                            "timeZone": "UTC",
                            "schedule": {
                                "hours": [17],
                                "minutes": [0]
                            }
                        },
                        "action": "Stop",
                        "status": "Enabled"
                    }
                ]
            }
        }

- Azure Resource Name: Azure Machine Learning Compute Instance

### Properties: 
- ComputeType
- vmSize
- subnet
- objectId
- tentantId
- scripts
- schedules

### Values of properties:
- ComputeType - ComputeInstance
- vmSize - [parameters('vmSize')]
- subnet - [parameters('subnet')]
- objectId - [parameters('objectId')]
- tentantId - [parameters('tenantId')]
- scripts - 
creationScript": {
                    "scriptSource": "inline",
                    "scriptData": "[base64(parameters('inlineCommand'))]",
                    "scriptArguments": "[parameters
}
- schedules - [parameters('schedules')]

SCIA specific changes: NA


