## Resource: 
'Microsoft.MachineLearningServices/workspaces'

## Usage: 
This template creates the following Azure services:
- Azure Storage Account
- Azure Key Vault
- Azure Application Insights
- Azure Container Registry
- Azure Machine Learning workspace
The resource group is the container that holds the services. The various services are required by the Azure Machine Learning workspace.
- The location where the resources will be created.
The template will use the location you select for most resources. The exception is the Application Insights service, which is not available in all of the locations that the other services are. If you select a location where it is not available, the service will be created in the South Central US location.
- The workspaceName, which is the friendly name of the Azure Machine Learning workspace.
Objective: This template creates a new Azure Machine Learning Workspace, along with a Storage Account, KeyVault and Applications Insights Logging.

## Pre-req: 
Need to have valid subscription

## Steps:
- Copy the azuremlworkspace.json from templates/azuremlworkspace.json in from Platform-Devops-ARM-library repo.
- Navigate to Azure portal and select option "Custom Deployment"
- Select option "Build our own template"
- Paste the template of Step 1 in the editor and Click on Save
- User will be presented to edit the parameters below, please select or enter the values of the parameters as specified
- Once all parameters specified, click on review and creation option, this will validate the template
- if the validation is passed, click to create mlworkspace template



## Parameters:
- Subscription : select the subscription name from the drop down in which ml to be deployed
- Resource group : Select an existing resource group where a resource need to be deployed or create a new resource group by clicking "Create New" link
- Region : Select region where the resource need to be deployed
- workspaceName: Specifies the name of the Azure Machine Learning workspace given in Alphanumerics and hyphens
- environment: Specifies the name of the environment given in plane text
- Location : Specifies the Azure location where the ml workspace should be created, user need not enter this as its fetched by default using resougseGroup.location
- hbi_workspace: Type for this field is string, user need to specify true or false
- false : not reduce telemetry collection and not enable additional encryption
- true : reduce telemetry collection and enable additional encryption

### Default Values: 
- workspaceName
- storageAccountName
- KeyVaultName
- applictionInsightsName
- location 

### Description: 
To create an Azure Machine Learning workspace using Azure Resource Manager templates, A Resource Manager template makes it easy to create resources as a single, coordinated operation. A template is a JSON document that defines the resources that are needed for a deployment. It may also specify deployment parameters. Parameters are used to provide input values when using the template.


### Properties: 
- friendlyName - specifies the name of the azure ML workspace
- storageAccount - Name for the storage account to created and associated with the workspace
- keyVault - Name for the keyvault to created and associated with the workspace
- applicationInsightsName - Name for the application insights to created and associated with the workspace

### Values of properties:
- workspaceName - [parameters('workspaceName')]
- storageAccountName - [parameters('storageAccountName')]
- KeyVaultName - [parameters('keyVaultName')]
- applictionInsightsName - [parameters('applicationInsightsName')]
- location - [parameters('location')]

SCIA specific changes: NA
