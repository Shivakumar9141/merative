### Deployment Script

Convert windows formated files to unix
```
find . -type f -print0 | xargs -0 dos2unix
```
Create package and deploy using docker
```
docker build -t <image-name>
docker run -it --rm --name <container-name> -v ${PWD}:/usr/src/arm-code <image-name> bash
az login
scripts/deployment.sh
```
Create package and deploy on non-docker platforms
```
az login
scripts/deployment.sh
```
Run unit tests only
```
pwsh scripts/UnitTests.ps1
```
#### [Azure Resources](https://github.com/wh-devOps/Platform-Devops-ARM-library/blob/d80893c7504f78b85873280234401f381dce52e6/docs/azureresources.md)
