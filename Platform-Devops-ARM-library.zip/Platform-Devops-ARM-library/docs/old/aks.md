### Azure Kuberenetes Service

### Description

Azure Kubernetes Service (AKS) simplifies deploying a managed Kubernetes cluster in Azure by offloading the operational overhead to Azure. As a hosted Kubernetes service, Azure handles critical tasks, like health monitoring and maintenance. Since Kubernetes masters are managed by Azure, you only manage and maintain the agent nodes.
Usage:-  It is an open source container orchestration system for automating computer application deployment, scaling and management. the Kubernetes master and all nodes are deployed and configured for you. Advanced networking, Azure Active Directory (Azure AD) integration, monitoring, and other features can be configured during the deployment process, we need to configure the azure profile in the AD and get the aadProfile_AdminGroup_ObjectID for the resources to enable communication.

### Prerequisites:-  
- User assigned identity : Execute the ARM template of useridentifty.json and get the userDefinedIdentityId from Azure portal.
- Existing vnet and subnet : Created during SCIA network infrastructre creation, get the name of the vnet and subnet
- aadProfile_AdminGroup_ObjectID if AAD profile needs to be turn on 
	- User with owners access can create this on azure under azure active directory
	- Get the aadProfile_AdminGroup_ObjectID

#### Parameters

##### name
- type : string
- description : Specifies the name of the Managed Cluster resource

##### Location
- type : string
- description : Specifies the Azure location where the aks should be created.

##### osDiskSizeGB
- type : int
- description : Disk size (in GB) to provision for each of the agent pool nodes. This value     ranges from 0 to 1023. Specifying 0 will apply the default disk size for that agentVMSize."

##### existingVnetName
- type : string
- description :  Virtual Network Name

##### existingVnetSubnetName
- type : string
- description : Virtual Network Subnet Name


##### enableRBAC 
- type : bool
- description : boolean flag to turn on and off of RBAC

##### workspaceResourceGroup 
- type : string
- description : Log Analytics workspace resource group name

##### enableMonitorAndLogging
- type : string
- description : To enable or disable Monitoring and Logging for AKS

##### enablePrivateCluster
- type : string
- description : Specifies whether to create the cluster as a private cluster or not

##### userAssignedIdentityId
- type : string
- description- User Assigned Managed Identity for AKS

##### aadProfileAdminGroupObjectIDs
- type : string
- description : Specifies the AAD group object IDs that will have admin role of the cluster

##### aadProfileEnableAzureRBAC
- type : string
- description : Specifies the AAD group object IDs that will have admin role of the cluster

####  Azure Resource Type
	Microsoft.ContainerService/managedClusters
	
#### Properties

- addonProfiles
- agentPoolProfiles
- aadProfile
- networkProfile
- apiServerAccessProfile
#### SCIA Specific Changes:- 
1.	enablePrivateCluster
2.	aadProfile

#### [ARM Template Path](/templates/aks.json)
