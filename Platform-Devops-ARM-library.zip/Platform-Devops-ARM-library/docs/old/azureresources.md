
## platform-arm-library

This repo contains a package of azure ARM templates which is configured to provision platform related reosurces in the azure cloud. The ARM templates are to be stored in templates specs, which are used to deploy resources to the cloud at deployment time.

### Prerequisites

- Active Azure Subscription
- Linux Distribution (preferbly Ubuntu 20.04 or WSL2)
- Azure CLI version 2.30 or Azure Cloud Shell
- do2unix
- jq
- PowerShell version 7
- Python 3.6 or above (comes along with the Azure CLI installation)
- Docker ( for local testing )

### ARM Templates List

- AKS Cluster with multiple node pools and Azure AD Integration (add-ons and configurations are customizable)
- KeyVault with access policies
- Storage Account with multiple blob containers
- User Assigned Managed Identities
- ### Azure Role assignment for User Assigned Manged Identies (currently only below roles are assigned)
  - #### Acr Pull
  - #### Storage Account Contributor
  - #### [KeyVault](https://github.com/wh-devOps/Platform-Devops-ARM-library/blob/49edeb52157fce366ae9be2255b41680e04e99f1/docs/keyVault.md) 
- Private Endpoints (dependent on Vnet and Subnet service endopint creation)
- Private DNS Zones and Virtual Network Linking (dependent on Vnet and Subnet service endopint creation)
- Azure Container Registry
- Azure PostgreSQL Single Server
- Azure PostgreSQL Flexi Server
- Azure CosmosDB
  - Mongo API
  - SQL API
- Azure Resource Locks
- HD Insights Cluster (Apache Spark)
- Virtual Machines with Data disks
- Availability Sets
- Load Balancers
- Azure Machine Learning Instances

#### [Deployment](https://github.com/wh-devOps/Platform-Devops-ARM-library/blob/sks-editdocs/docs/deployment.md)
#### [About Us](https://github.com/wh-devOps/Platform-Devops-ARM-library/blob/sks-editdocs/docs/index.md)
