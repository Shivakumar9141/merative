## Key Vault 
Azure Key Vault is a cloud service that provides a secure store for secrets, such as keys, passwords, certificates, and other secrets.

### Description
Azure Key Vault is a cloud service for securely storing and accessing secrets. A secret is anything that you want to tightly control access to, such as API keys, passwords, certificates, or cryptographic keys.

### Usage 
Centralizing storage of application secrets in Azure Key Vault allows you to control their distribution. Key Vault greatly reduces the chances that secrets may be accidentally leaked. When using Key Vault, application developers no longer need to store security information in their application. Not having to store security information in applications eliminates the need to make this information part of the code. For example, an application may need to connect to a database. Instead of storing the connection string in the app's code, you can store it securely in Key Vault.

### Pre-req
NA
  
### Parameters : 

- keyVaultName
- type : string
- description : Specifies the name of the key vault. enter a name for the key vault, which must be globally unique across Azure.

- Location
- type: string
- description- Specifies the Azure location where the key vault should be created.

- enabledForDeployment
- type : bool
- description : Specifies whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault.

- enabledForDiskEncryption
- type : bool
- description : Specifies whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys.

- enabledForTemplateDeployment
- type : bool
- description : Specifies whether Azure Resource Manager is permitted to retrieve secrets from the key vault.



- enableRbacAuthorization
- type : bool
- description : Property that controls how data actions are authorized. When true, the key vault will use Role Based Access Control (RBAC) for authorization of data actions, and the access policies specified in vault properties will be ignored. When false, the key vault will use the access policies specified in vault properties, and any policy stored on Azure Resource Manager will be ignored. If null or not specified, the vault is created with the default value of false. Note that management actions are always authorized with RBAC.

- enableSoftDelete
- type : bool
- description : Property to specify whether the 'soft delete' functionality is enabled for this key vault. If it's not set to any value(true or false) when creating new key vault, it will be set to true by default. Once set to true, it cannot be reverted to false.

- tenantId
- type : String
- description : Specifies the Azure Active Directory tenant ID that should be used for authenticating requests to the key vault.


- keysPermissions
- type : array
- description : Specifies the permissions to keys in the vault. Valid values are: all, encrypt, decrypt, wrapKey, unwrapKey, sign, verify, get, list, create, update, import, delete, backup, restore, recover, and purge.
 
- secretsPermissions
- type : array
- description : Specifies the permissions to secrets in the vault. Valid values are: all,    get, list, set, delete, backup, restore, recover, and purge.
     
 
- certificatePermissions
- type : array
- description : Specifies the permissions to certificates in the vault. Valid values are: all,      get, list, set, delete, backup, restore, recover, and purge.


- skuName
- type : string
- description : Specifies whether the key vault is a standard vault or a premium vault.

      
- objectId
- type – securestring
- description : The object ID of a user, service principal or security group in the Azure  Active Directory tenant for the vault. The object ID must be unique for the list of access  policies.



### Azure Resource Type 
  - "Microsoft.KeyVault/vaults" : Microsoft.KeyVault/vaults
	- Properties
	- enabledForDeployment
	- enabledForDiskEncryption
  - enabledForTemplateDeployment
  - enableRbacAuthorization
  - enableSoftDelete
  - enablePurgeProtection
  - tenantId
  - accessPolicies
          
### SCIA Specific Changes 
- enableRbacAuthorization

#### [Azure Resources](azureresources.md)
	
