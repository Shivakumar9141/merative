
# platform-arm-library
This repo contains a package of azure ARM templates which is configured to provision platform related reosurces in the azure cloud. The ARM templates are to be stored in templates specs, which are used to deploy resources to the cloud at deployment time.



## Prerequisites
- Active Azure Subscription
- Linux Distribution (preferbly Ubuntu 20.04 or WSL2)
- Azure CLI version 2.30 or Azure Cloud Shell
- do2unix
- jq
- PowerShell version 7
- Python 3.6 or above (comes along with the Azure CLI installation)
- Docker ( *for local testing* )


## Features

- AKS Cluster with multiple node pools and Azure AD integration (add-ons and configurations are   customizable)
- KeyVault with access policies
- Storage Account with multiple blob containers
- User Assigned Managed Identities
- Azure Role assignment for User Assigned Manged Identies (currently only below roles are assigned)
  - Acr Pull
  - Storage Account Contributor
  - KeyVault Reader
- Private Endpoints (dependent on Vnet and Subnet service endopint creation)
- Private DNS Zones and Virtual Network Linking (dependent on Vnet and Subnet service endopint creation)
- Azure Container Registry
- Azure PostgreSQL Single Server
- Azure PostgreSQL Flexi Server
- Azure CosmosDB
  - Mongo API
  - SQL API
- Azure Resource Locks
- HD Insights Cluster (Apache Spark)
- Virtual Machines with Data disks
- Availability Sets
- Load Balancers
- Azure Machine Learning Instances

## Current Test Status

![ARM Tests](https://github.com/wh-devOps/Platform-Devops-ARM-library/actions/workflows/main.yml/badge.svg)

## Testing
Unit tests are now removed as a part of deployment because github actions take care of unit tests when the code is pushed or a pull request is raised.
## Usage/Examples

Convert windows formated files to unix
```
find . -type f -print0 | xargs -0 dos2unix
```
Create package and deploy using docker
```
docker build -t <image-name>
docker run -it --rm --name <container-name> -v ${PWD}:/usr/src/arm-code <image-name> bash
az login
scripts/deployment.sh
```
Create package and deploy on non-docker platforms
```
az login
scripts/deployment.sh
```
Run unit tests only
```
pwsh scripts/UnitTests.ps1
```
